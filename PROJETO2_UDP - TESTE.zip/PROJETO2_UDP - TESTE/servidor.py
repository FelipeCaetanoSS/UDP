import socket
import os
from utils import receber_janela, enviar_janela

IP = "192.168.18.239"
PORTA = 60000
PASTA_ARQUIVOS = "arquivos_servidor"

os.makedirs(PASTA_ARQUIVOS, exist_ok=True)

def tratar_cliente(sock, dados, endereco):
    opcao = dados.decode().strip()
    print(f"Comando: {opcao} de {endereco}")

    if opcao == "LISTAR":
        arquivos = os.listdir(PASTA_ARQUIVOS)
        resposta = "\n".join(arquivos) if arquivos else "Nenhum arquivo disponível."
        sock.sendto(resposta.encode(), endereco)

    elif opcao.startswith("UPLOAD"):
        nome = opcao.split(" ", 1)[1]
        caminho = os.path.join(PASTA_ARQUIVOS, nome)
        
        sock.sendto(b"OK", endereco)
        dados_arquivo = receber_janela(sock, endereco)
        
        if dados_arquivo:
            with open(caminho, "wb") as f:
                f.write(dados_arquivo)
            print(f"'{nome}' salvo ({len(dados_arquivo)} bytes)")

    elif opcao.startswith("DOWNLOAD"):
        nome = opcao.split(" ", 1)[1]
        caminho = os.path.join(PASTA_ARQUIVOS, nome)

        if not os.path.exists(caminho):
            sock.sendto(b"ERRO", endereco)
            return

        sock.sendto(b"OK", endereco)
        with open(caminho, "rb") as f:
            enviar_janela(sock, f.read(), endereco)
        print(f"'{nome}' enviado")

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORTA))
print(f"Servidor em {IP}:{PORTA}")

while True:
    dados, endereco = sock.recvfrom(2048)
    tratar_cliente(sock, dados, endereco)