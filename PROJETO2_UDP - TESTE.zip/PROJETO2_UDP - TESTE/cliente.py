import socket
from utils import enviar_janela, receber_janela
from tkinter import filedialog
import os

IP_SERVIDOR = "10.164.20.68"
PORTA = 60000
cliente = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
cliente.settimeout(5)

def listar():
    cliente.sendto(b"LISTAR", (IP_SERVIDOR, PORTA))
    dados, _ = cliente.recvfrom(4096)
    print("\nArquivos:\n" + dados.decode())
11

def upload():
    caminho = filedialog.askopenfilename(title="Escolha um arquivo")
    if not caminho:
        return
        
    nome = os.path.basename(caminho)
    cliente.sendto(f"UPLOAD {nome}".encode(), (IP_SERVIDOR, PORTA))
    
    resposta, _ = cliente.recvfrom(1024)
    if resposta == b"OK":
        with open(caminho, "rb") as f:
            enviar_janela(cliente, f.read(), (IP_SERVIDOR, PORTA))
        print("Upload concluído.")

def download():
    nome = input("Nome do arquivo: ")
    cliente.sendto(f"DOWNLOAD {nome}".encode(), (IP_SERVIDOR, PORTA))

    resposta, _ = cliente.recvfrom(1024)
    if resposta == b"ERRO":
        print("Arquivo não encontrado.")
        return

    dados_arquivo = receber_janela(cliente, (IP_SERVIDOR, PORTA))
    if dados_arquivo:
        with open(nome, "wb") as f:
            f.write(dados_arquivo)
        print("Download completo.")

while True:
    print("\n1. Listar\n2. Upload\n3. Download\n4. Sair")
    op = input("Opção: ")
    
    if op == "1":
        listar()
    elif op == "2":
        upload()
    elif op == "3":
        download()
    elif op == "4":
        break