import socket
from utils import enviar_janela, receber_janela
from tkinter import filedialog
import os

# IP do servidor ao qual o cliente irá se conectar.
IP_SERVIDOR = "10.164.20.68"
# Porta de comunicação com o servidor.
PORTA = 58412
# Cria um socket UDP (SOCK_DGRAM) para comunicação.
cliente = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# Define um tempo limite (timeout) para operações de socket em 5 segundos.
cliente.settimeout(5)

def listar():
    """
    Envia um comando 'LISTAR' para o servidor para solicitar a lista de arquivos disponíveis.
    Recebe a resposta do servidor e a imprime no console.
    """
    # Envia o comando "LISTAR" para o servidor.
    cliente.sendto(b"LISTAR", (IP_SERVIDOR, PORTA))
    # Recebe os dados (lista de arquivos) do servidor. O segundo valor retornado é o endereço, que não é usado aqui.
    dados, _ = cliente.recvfrom(4096)
    # Decodifica os dados recebidos (bytes para string) e imprime.
    print("\nArquivos:\n" + dados.decode())

def upload():
    """
    Permite ao usuário selecionar um arquivo local para fazer upload para o servidor.
    Envia o nome do arquivo para o servidor, aguarda confirmação e então envia o conteúdo do arquivo
    usando a função de janela deslizante.
    """
    # Abre uma caixa de diálogo para o usuário selecionar um arquivo.
    caminho = filedialog.askopenfilename(title="Escolha um arquivo")
    # Se o usuário cancelar a seleção, retorna.
    if not caminho:
        return
        
    # Extrai apenas o nome do arquivo do caminho completo.
    nome = os.path.basename(caminho)
    # Envia o comando "UPLOAD" seguido do nome do arquivo para o servidor.
    cliente.sendto(f"UPLOAD {nome}".encode(), (IP_SERVIDOR, PORTA))
    
    # Aguarda a resposta do servidor (esperando "OK" para prosseguir com o upload).
    resposta, _ = cliente.recvfrom(1024)
    # Se a resposta for "OK", o servidor está pronto para receber o arquivo.
    if resposta == b"OK":
        # Abre o arquivo selecionado em modo de leitura binária.
        with open(caminho, "rb") as f:
            # Lê todo o conteúdo do arquivo e o envia para o servidor usando a função de janela deslizante.
            enviar_janela(cliente, f.read(), (IP_SERVIDOR, PORTA))
        print("Upload concluído.")

def download():
    """
    Solicita ao usuário o nome de um arquivo para download do servidor.
    Envia o comando 'DOWNLOAD' para o servidor, verifica se o arquivo existe
    e, se sim, recebe o conteúdo do arquivo usando a função de janela deslizante e o salva localmente.
    """
    # Solicita ao usuário o nome do arquivo a ser baixado.
    nome = input("Nome do arquivo: ")
    # Envia o comando "DOWNLOAD" seguido do nome do arquivo para o servidor.
    cliente.sendto(f"DOWNLOAD {nome}".encode(), (IP_SERVIDOR, PORTA))

    # Aguarda a resposta do servidor (esperando "OK" ou "ERRO").
    resposta, _ = cliente.recvfrom(1024)
    # Se a resposta for "ERRO", o arquivo não foi encontrado no servidor.
    if resposta == b"ERRO":
        print("Arquivo não encontrado.")
        return

    # Se a resposta não for "ERRO" (presumindo "OK"), começa a receber os dados do arquivo
    # usando a função de janela deslizante.
    dados_arquivo = receber_janela(cliente, (IP_SERVIDOR, PORTA))
    # Se dados foram recebidos com sucesso.
    if dados_arquivo:
        # Abre (ou cria) o arquivo localmente em modo de escrita binária.
        with open(nome, "wb") as f:
            # Escreve os dados recebidos no arquivo.
            f.write(dados_arquivo)
        print("Download completo.")

# Loop principal do cliente para interagir com o usuário.
while True:
    # Exibe o menu de opções.
    print("\n1. Listar\n2. Upload\n3. Download\n4. Sair")
    # Pede a opção ao usuário.
    op = input("Opção: ")
    
    # Executa a função correspondente à opção escolhida.
    if op == "1":
        listar()
    elif op == "2":
        upload()
    elif op == "3":
        download()
    elif op == "4":
        # Sai do loop e encerra o cliente.
        break