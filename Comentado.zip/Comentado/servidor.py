import socket
import os
import random # Importar para simular perda de pacotes
from utils import receber_janela, enviar_janela

# IP em que o servidor irá escutar. Use "0.0.0.0" para escutar em todas as interfaces disponíveis.
# O IP "192.168.18.239" pode ser o IP específico da máquina do servidor na rede local.
IP = "192.168.18.239"
# Porta em que o servidor irá escutar as conexões dos clientes.
PORTA = 60000
# Pasta onde os arquivos serão armazenados no servidor.
PASTA_ARQUIVOS = "arquivos_servidor"

# Garante que a pasta de arquivos exista. Se não existir, ela será criada.
os.makedirs(PASTA_ARQUIVOS, exist_ok=True)

def tratar_cliente(sock, dados, endereco):
    """
    Trata as requisições de um cliente (LISTAR, UPLOAD, DOWNLOAD).
    
    Args:
        sock (socket.socket): O socket UDP do servidor usado para comunicação.
        dados (bytes): Os dados recebidos do cliente, representando a requisição.
        endereco (tuple): O endereço (IP, Porta) do cliente que enviou a requisição.
    """
    # Decodifica a requisição do cliente e remove espaços em branco extras.
    opcao = dados.decode().strip()
    print(f"Comando: {opcao} de {endereco}")

    # Lógica para o comando LISTAR.
    if opcao == "LISTAR":
        # Lista todos os arquivos na pasta do servidor.
        arquivos = os.listdir(PASTA_ARQUIVOS)
        # Formata a lista de arquivos para enviar ao cliente.
        resposta = "\n".join(arquivos) if arquivos else "Nenhum arquivo disponível."
        # Envia a lista de arquivos de volta ao cliente.
        sock.sendto(resposta.encode(), endereco)

    # Lógica para o comando UPLOAD.
    elif opcao.startswith("UPLOAD"):
        # Extrai o nome do arquivo da requisição.
        nome = opcao.split(" ", 1)[1]
        # Constrói o caminho completo para salvar o arquivo no servidor.
        caminho = os.path.join(PASTA_ARQUIVOS, nome)
        
        # Envia um "OK" para o cliente, indicando que o servidor está pronto para receber o arquivo.
        sock.sendto(b"OK", endereco)
        # Recebe os dados do arquivo do cliente usando a função de janela deslizante.
        dados_arquivo = receber_janela(sock, endereco)
        
        # Se dados foram recebidos com sucesso.
        if dados_arquivo:
            # Abre (ou cria) o arquivo no servidor em modo de escrita binária.
            with open(caminho, "wb") as f:
                # Escreve os dados recebidos no arquivo.
                f.write(dados_arquivo)
            print(f"'{nome}' salvo ({len(dados_arquivo)} bytes)")

    # Lógica para o comando DOWNLOAD.
    elif opcao.startswith("DOWNLOAD"):
        # Extrai o nome do arquivo da requisição.
        nome = opcao.split(" ", 1)[1]
        # Constrói o caminho completo do arquivo no servidor.
        caminho = os.path.join(PASTA_ARQUIVOS, nome)

        # Verifica se o arquivo existe no servidor.
        if not os.path.exists(caminho):
            # Se o arquivo não existe, envia um "ERRO" ao cliente.
            sock.sendto(b"ERRO", endereco)
            return

        # Se o arquivo existe, envia um "OK" ao cliente.
        sock.sendto(b"OK", endereco)
        # Abre o arquivo em modo de leitura binária.
        with open(caminho, "rb") as f:
            # Envia o conteúdo do arquivo para o cliente usando a função de janela deslizante.
            enviar_janela(sock, f.read(), endereco)
        print(f"'{nome}' enviado")

# Cria um socket UDP (SOCK_DGRAM) para o servidor.
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# Associa o socket ao IP e porta definidos. Isso faz com que o servidor comece a "escutar"
# por pacotes recebidos nesse endereço e porta.
sock.bind((IP, PORTA))

# Configura um timeout geral para o socket do servidor.
# Isso ajuda a evitar que o servidor fique bloqueado indefinidamente
# se não houver atividade. O tratamento específico de timeouts para
# envio e recebimento de janelas é feito nas funções 'enviar_janela'
# e 'receber_janela' em 'utils.py'.
sock.settimeout(1.0) # Define um timeout de 1 segundo para recvfrom

print(f"Servidor em {IP}:{PORTA}")

# Loop principal do servidor para receber e tratar requisições.
while True:
    try:
        # Tenta receber dados de qualquer cliente. O tamanho máximo do pacote é 2048 bytes.
        dados, endereco = sock.recvfrom(2048)
        
        # # Simulação de perda de pacotes (descomente para ativar)
        # # Altere a probabilidade (e.g., 0.1 para 10% de perda)
        # if random.random() < 0.1: 
        #     print(f"DEBUG: Pacote de {endereco} descartado propositalmente.")
        #     continue 
            
        # Chama a função para tratar a requisição do cliente.
        tratar_cliente(sock, dados, endereco)
    except socket.timeout:
        # Este bloco será executado se o recvfrom principal do servidor
        # exceder o tempo limite. É útil para manter o loop ativo e 
        # permitir verificações periódicas ou encerramento gracioso.
        # Por exemplo, você pode adicionar lógica para monitoramento aqui.
        pass
    except Exception as e:
        # Captura e imprime quaisquer outras exceções que possam ocorrer durante o tratamento.
        print(f"Erro no servidor: {e}")