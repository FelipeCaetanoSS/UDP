import socket
import struct

# Tempo limite para operações de socket (em segundos) dentro das funções de janela.
TIMEOUT = 3
# Tamanho da janela deslizante, ou seja, o número máximo de pacotes que podem ser enviados
# antes de esperar por uma confirmação (ACK).
WINDOW_SIZE = 5
# Tamanho de cada pedaço de dados (chunk) que será enviado em um pacote.
CHUNK_SIZE = 1024

def criar_pacote(tipo, seq, dados=b""):
    """
    Cria um pacote UDP com um cabeçalho fixo e dados opcionais.
    O cabeçalho contém o tipo do pacote (1 byte) e o número de sequência (4 bytes).
    
    Args:
        tipo (int): Tipo do pacote (e.g., 1 para DADOS, 2 para ACK, 3 para FIM).
        seq (int): Número de sequência do pacote.
        dados (bytes, optional): Carga útil de dados do pacote. Padrão é bytes vazios.

    Returns:
        bytes: O pacote completo pronto para ser enviado via socket.
    """
    # "!BI" significa:
    # !: Ordem de byte de rede (network byte order).
    # B: unsigned char (1 byte para o tipo).
    # I: unsigned int (4 bytes para o número de sequência).
    return struct.pack("!BI", tipo, seq) + dados

def interpretar_pacote(pacote):
    """
    Interpreta um pacote UDP recebido, extraindo o tipo, o número de sequência e os dados.
    
    Args:
        pacote (bytes): O pacote UDP recebido.

    Returns:
        tuple: Uma tupla contendo (tipo, seq, dados). Retorna (None, None, None) se o pacote for inválido.
    """
    # Verifica se o pacote tem pelo menos o tamanho do cabeçalho (5 bytes).
    if len(pacote) < 5:
        return None, None, None
    # Desempacota os primeiros 5 bytes para obter o tipo e o número de sequência.
    tipo, seq = struct.unpack("!BI", pacote[:5])
    # Retorna o tipo, a sequência e o restante do pacote como dados.
    return tipo, seq, pacote[5:]

def enviar_janela(sock, dados, addr):
    """
    Envia uma quantidade arbitrária de dados de forma confiável usando o protocolo de janela deslizante.
    Divide os dados em chunks, empacota-os e os envia em janelas, aguardando ACKs para avançar a janela.
    
    Args:
        sock (socket.socket): O socket UDP a ser usado para o envio.
        dados (bytes): Os dados completos a serem enviados.
        addr (tuple): O endereço (IP, Porta) do destinatário.
    """
    # Se não houver dados para enviar, envia um pacote de FIM e retorna.
    if not dados:
        sock.sendto(criar_pacote(3, 0), addr)  # Tipo 3 = FIM
        return

    pacotes = []
    # Divide os dados em chunks e cria pacotes de DADOS (tipo 1).
    for i, offset in enumerate(range(0, len(dados), CHUNK_SIZE)):
        chunk = dados[offset:offset + CHUNK_SIZE]
        pacotes.append(criar_pacote(1, i, chunk))  # Tipo 1 = DADOS

    # 'base' é o número de sequência do primeiro pacote na janela atual que ainda não foi confirmado.
    base = 0
    # Define o timeout para as operações de recvfrom neste socket.
    sock.settimeout(TIMEOUT)
    
    # Loop principal para o envio da janela deslizante.
    while base < len(pacotes):
        # Envia os pacotes dentro da janela atual.
        for i in range(base, min(base + WINDOW_SIZE, len(pacotes))):
            sock.sendto(pacotes[i], addr)

        # Aguarda ACKs do receptor.
        try:
            # Tenta receber um ACK.
            ack_data, _ = sock.recvfrom(1024)
            # Interpreta o pacote ACK recebido.
            tipo, ack_seq, _ = interpretar_pacote(ack_data)
            # Se o pacote é um ACK (tipo 2) e o número de sequência do ACK é maior ou igual à base,
            # significa que os pacotes até 'ack_seq' foram recebidos. Avança a base da janela.
            if tipo == 2 and ack_seq >= base:  # Tipo 2 = ACK
                base = ack_seq + 1
        except socket.timeout:
            # Se ocorrer um timeout, significa que não recebemos ACKs a tempo.
            # A janela atual será reenviada na próxima iteração do loop 'while base < len(pacotes)'.
            pass  # Reenvia janela

    # Após enviar todos os dados e receber os ACKs, envia pacotes de FIM (tipo 3) para sinalizar o término.
    # Envia múltiplas vezes para aumentar a robustez contra perda do pacote FIM.
    for _ in range(3):
        sock.sendto(criar_pacote(3, 0), addr)

def receber_janela(sock, addr):
    """
    Recebe dados de forma confiável usando o protocolo de janela deslizante.
    Aguarda pacotes de dados, envia ACKs para cada pacote recebido e reconstrói os dados completos.
    
    Args:
        sock (socket.socket): O socket UDP a ser usado para o recebimento.
        addr (tuple): O endereço (IP, Porta) do remetente esperado. Isso é importante para filtrar pacotes.

    Returns:
        bytes: Os dados completos recebidos, ou None se nenhum dado foi recebido.
    """
    dados_recebidos = {} # Dicionário para armazenar os chunks de dados por número de sequência.
    # Define um timeout mais longo para o recebimento, pois pode haver longos períodos sem dados
    # se o remetente estiver lento ou houver perda de pacotes.
    sock.settimeout(TIMEOUT * 2)
    
    while True:
        try:
            # Tenta receber um pacote.
            pacote_data, endereco = sock.recvfrom(2048)
            # Ignora pacotes que não vêm do endereço esperado.
            if endereco != addr:
                continue
                
            # Interpreta o pacote recebido.
            tipo, seq, dados = interpretar_pacote(pacote_data)
            
            # Se o tipo for FIM (3), significa que a transmissão terminou. Envia um ACK e sai do loop.
            if tipo == 3:  # FIM
                sock.sendto(criar_pacote(2, seq), endereco)  # Envia ACK para o pacote FIM
                break
            # Se o tipo for DADOS (1), armazena os dados pelo seu número de sequência e envia um ACK.
            elif tipo == 1:  # DADOS
                dados_recebidos[seq] = dados
                sock.sendto(criar_pacote(2, seq), endereco)  # Envia ACK para o pacote de dados
                
        except socket.timeout:
            # Se ocorrer um timeout, significa que não há mais pacotes chegando ou a transmissão parou.
            # Sai do loop de recebimento.
            break

    # Reconstrói os dados completos a partir dos chunks recebidos, ordenando-os pelos números de sequência.
    if dados_recebidos:
        resultado = b""
        for i in sorted(dados_recebidos.keys()):
            resultado += dados_recebidos[i]
        return resultado
    # Retorna None se nenhum dado foi recebido.
    return None