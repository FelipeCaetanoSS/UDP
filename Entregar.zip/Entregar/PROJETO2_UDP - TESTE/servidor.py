import socket
import os
import random
from utils import receber_janela, enviar_janela

# Define o IP e a porta onde o servidor vai escutar
IP = "192.168.18.239"
PORTA = 60000

# Define a pasta onde os arquivos serão armazenados no servidor
PASTA_ARQUIVOS = "arquivos_servidor"

# Cria a pasta se ela não existir
os.makedirs(PASTA_ARQUIVOS, exist_ok=True)

# Função que trata as requisições de um cliente
def tratar_cliente(sock, dados, endereco):
    # Decodifica os dados recebidos (texto enviado pelo cliente)
    opcao = dados.decode().strip()
    print(f"Comando: {opcao} de {endereco}")

    # Se o cliente pediu para listar os arquivos
    if opcao == "LISTAR":
        # Lista os arquivos na pasta do servidor
        arquivos = os.listdir(PASTA_ARQUIVOS)
        # Prepara a resposta: lista ou mensagem de que não há arquivos
        resposta = "\n".join(arquivos) if arquivos else "Nenhum arquivo disponível."
        # Envia a resposta de volta ao cliente
        sock.sendto(resposta.encode(), endereco)

    # Se o cliente quer fazer upload de um arquivo
    elif opcao.startswith("UPLOAD"):
        # Extrai o nome do arquivo
        nome = opcao.split(" ", 1)[1]
        # Define o caminho completo onde o arquivo será salvo
        caminho = os.path.join(PASTA_ARQUIVOS, nome)
        # Envia confirmação para o cliente começar a enviar o arquivo
        sock.sendto(b"OK", endereco)
        # Recebe os dados do arquivo usando protocolo de janelas
        dados_arquivo = receber_janela(sock, endereco)
        if dados_arquivo:
            # Salva o arquivo recebido no servidor
            with open(caminho, "wb") as f:
                f.write(dados_arquivo)
            print(f"'{nome}' salvo ({len(dados_arquivo)} bytes)")

    # Se o cliente quer fazer download de um arquivo
    elif opcao.startswith("DOWNLOAD"):
        # Extrai o nome do arquivo solicitado
        nome = opcao.split(" ", 1)[1]
        # Define o caminho completo do arquivo
        caminho = os.path.join(PASTA_ARQUIVOS, nome)
        # Verifica se o arquivo existe no servidor
        if not os.path.exists(caminho):
            # Envia erro se não encontrado
            sock.sendto(b"ERRO", endereco)
            return
        # Envia confirmação para o cliente
        sock.sendto(b"OK", endereco)
        # Lê o conteúdo do arquivo e envia usando protocolo de janelas
        with open(caminho, "rb") as f:
            enviar_janela(sock, f.read(), endereco)
        print(f"'{nome}' enviado")

# Cria o socket UDP do servidor
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Liga o socket ao IP e porta definidos
sock.bind((IP, PORTA))

# Define um tempo limite para chamadas bloqueantes de recepção (em segundos)
sock.settimeout(1.0)

print(f"Servidor em {IP}:{PORTA}")

# Loop principal do servidor
while True:
    try:
        # Aguarda o recebimento de dados de um cliente
        dados, endereco = sock.recvfrom(2048)

        # Simulação de perda de pacotes (pode ser usada para testes de robustez)
        # if random.random() < 0.1:
        #     print(f"DEBUG: Pacote de {endereco} descartado propositalmente.")
        #     continue

        # Processa o pedido do cliente
        tratar_cliente(sock, dados, endereco)

    # Ignora o timeout do socket (útil para permitir controle de fluxo no loop)
    except socket.timeout:
        pass

    # Captura e exibe qualquer outro erro inesperado
    except Exception as e:
        print(f"Erro no servidor: {e}")
