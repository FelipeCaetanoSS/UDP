import socket
import os
import random # Importar para simular perda de pacotes
from utils import receber_janela, enviar_janela

IP = "192.168.18.239"
PORTA = 60000
PASTA_ARQUIVOS = "arquivos_servidor"

os.makedirs(PASTA_ARQUIVOS, exist_ok=True)

def tratar_cliente(sock, dados, endereco):
    opcao = dados.decode().strip()
    print(f"Comando: {opcao} de {endereco}")

    if opcao == "LISTAR":
        arquivos = os.listdir(PASTA_ARQUIVOS)
        resposta = "\n".join(arquivos) if arquivos else "Nenhum arquivo disponível."
        sock.sendto(resposta.encode(), endereco)

    elif opcao.startswith("UPLOAD"):
        nome = opcao.split(" ", 1)[1]
        caminho = os.path.join(PASTA_ARQUIVOS, nome)
        
        sock.sendto(b"OK", endereco)
        dados_arquivo = receber_janela(sock, endereco)
        
        if dados_arquivo:
            with open(caminho, "wb") as f:
                f.write(dados_arquivo)
            print(f"'{nome}' salvo ({len(dados_arquivo)} bytes)")

    elif opcao.startswith("DOWNLOAD"):
        nome = opcao.split(" ", 1)[1]
        caminho = os.path.join(PASTA_ARQUIVOS, nome)

        if not os.path.exists(caminho):
            sock.sendto(b"ERRO", endereco)
            return

        sock.sendto(b"OK", endereco)
        with open(caminho, "rb") as f:
            enviar_janela(sock, f.read(), endereco)
        print(f"'{nome}' enviado")

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORTA))

# Configura um timeout geral para o socket do servidor.
# Isso ajuda a evitar que o servidor fique bloqueado indefinidamente
# se não houver atividade. O tratamento específico de timeouts para
# envio e recebimento de janelas é feito nas funções 'enviar_janela'
# e 'receber_janela' em 'utils.py'.
sock.settimeout(1.0) # Define um timeout de 1 segundo para recvfrom

print(f"Servidor em {IP}:{PORTA}")

while True:
    try:
        dados, endereco = sock.recvfrom(2048)
        
        # # Simulação de perda de pacotes (descomente para ativar)
        # # Altere a probabilidade (e.g., 0.1 para 10% de perda)
        # if random.random() < 0.1: 
        #     print(f"DEBUG: Pacote de {endereco} descartado propositalmente.")
        #     continue 
            
        tratar_cliente(sock, dados, endereco)
    except socket.timeout:
        # Este bloco será executado se o recvfrom principal do servidor
        # exceder o tempo limite. É útil para manter o loop ativo e 
        # permitir verificações periódicas ou encerramento gracioso.
        # Por exemplo, você pode adicionar lógica para monitoramento aqui.
        pass
    except Exception as e:
        print(f"Erro no servidor: {e}")