import socket
from utils import enviar_janela, receber_janela
from tkinter import filedialog
import os

# Define o endereço IP e porta do servidor
IP_SERVIDOR = "10.164.20.68"
PORTA = 58412

# Cria um socket UDP para o cliente
cliente = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Define o tempo limite de espera por resposta do servidor (em segundos)
cliente.settimeout(5)

# Função para listar arquivos disponíveis no servidor
def listar():
    # Envia a mensagem "LISTAR" para o servidor
    cliente.sendto(b"LISTAR", (IP_SERVIDOR, PORTA))
    
    # Aguarda a resposta com a lista de arquivos
    dados, _ = cliente.recvfrom(4096)
    
    # Exibe os arquivos recebidos
    print("\nArquivos:\n" + dados.decode())

# Função para fazer upload de um arquivo para o servidor
def upload():
    # Abre uma janela para o usuário escolher um arquivo
    caminho = filedialog.askopenfilename(title="Escolha um arquivo")
    
    # Se nenhum arquivo for selecionado, sai da função
    if not caminho:
        return

    # Extrai apenas o nome do arquivo (sem o caminho)
    nome = os.path.basename(caminho)
    
    # Envia o comando "UPLOAD <nome>" ao servidor
    cliente.sendto(f"UPLOAD {nome}".encode(), (IP_SERVIDOR, PORTA))
    
    # Aguarda resposta do servidor (espera um "OK")
    resposta, _ = cliente.recvfrom(1024)

    # Se o servidor aceitar o upload
    if resposta == b"OK":
        # Abre o arquivo e lê seu conteúdo em binário
        with open(caminho, "rb") as f:
            # Envia os dados utilizando a função personalizada de envio em janelas
            enviar_janela(cliente, f.read(), (IP_SERVIDOR, PORTA))
        print("Upload concluído.")

# Função para fazer download de um arquivo do servidor
def download():
    # Solicita ao usuário o nome do arquivo a ser baixado
    nome = input("Nome do arquivo: ")
    
    # Envia o comando "DOWNLOAD <nome>" ao servidor
    cliente.sendto(f"DOWNLOAD {nome}".encode(), (IP_SERVIDOR, PORTA))
    
    # Aguarda resposta do servidor
    resposta, _ = cliente.recvfrom(1024)

    # Se o servidor responder com "ERRO", o arquivo não existe
    if resposta == b"ERRO":
        print("Arquivo não encontrado.")
        return

    # Caso contrário, recebe os dados do arquivo
    dados_arquivo = receber_janela(cliente, (IP_SERVIDOR, PORTA))
    
    # Se os dados foram recebidos com sucesso
    if dados_arquivo:
        # Salva os dados em um novo arquivo com o nome original
        with open(nome, "wb") as f:
            f.write(dados_arquivo)
        print("Download completo.")

# Loop principal do programa
while True:
    print("\n1. Listar\n2. Upload\n3. Download\n4. Sair")
    op = input("Opção: ")
    if op == "1":
        listar()
    elif op == "2":
        upload()
    elif op == "3":
        download()
    elif op == "4":
        break  # Encerra o programa
