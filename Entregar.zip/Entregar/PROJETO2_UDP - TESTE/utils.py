import socket
import struct

TIMEOUT = 3
WINDOW_SIZE = 5
CHUNK_SIZE = 1024

def criar_pacote(tipo, seq, dados=b""):
    return struct.pack("!BI", tipo, seq) + dados

def interpretar_pacote(pacote):
    if len(pacote) < 5:
        return None, None, None
    tipo, seq = struct.unpack("!BI", pacote[:5])
    return tipo, seq, pacote[5:]

def enviar_janela(sock, dados, addr):
    if not dados:
        sock.sendto(criar_pacote(3, 0), addr)  # Pacote FIM
        return

    # Cria pacotes
    pacotes = []
    for i, offset in enumerate(range(0, len(dados), CHUNK_SIZE)):
        chunk = dados[offset:offset + CHUNK_SIZE]
        pacotes.append(criar_pacote(1, i, chunk))  # Tipo 1 = DADOS

    base = 0
    sock.settimeout(TIMEOUT)
    
    while base < len(pacotes):
        # Envia janela
        for i in range(base, min(base + WINDOW_SIZE, len(pacotes))):
            sock.sendto(pacotes[i], addr)

        # Aguarda ACKs
        try:
            ack_data, _ = sock.recvfrom(1024)
            tipo, ack_seq, _ = interpretar_pacote(ack_data)
            if tipo == 2 and ack_seq >= base:  # Tipo 2 = ACK
                base = ack_seq + 1
        except socket.timeout:
            pass  # Reenvia janela

    # Envia FIM
    for _ in range(3):
        sock.sendto(criar_pacote(3, 0), addr)

def receber_janela(sock, addr):
    dados_recebidos = {}
    sock.settimeout(TIMEOUT * 2)
    
    while True:
        try:
            pacote_data, endereco = sock.recvfrom(2048)
            if endereco != addr:
                continue
                
            tipo, seq, dados = interpretar_pacote(pacote_data)
            
            if tipo == 3:  # FIM
                sock.sendto(criar_pacote(2, seq), endereco)  # ACK
                break
            elif tipo == 1:  # DADOS
                dados_recebidos[seq] = dados
                sock.sendto(criar_pacote(2, seq), endereco)  # ACK
                
        except socket.timeout:
            break

    # Reconstroi dados
    if dados_recebidos:
        resultado = b""
        for i in sorted(dados_recebidos.keys()):
            resultado += dados_recebidos[i]
        return resultado
    return None