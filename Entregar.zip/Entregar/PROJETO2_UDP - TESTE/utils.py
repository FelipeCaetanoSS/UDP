import socket
import struct

# Tempo limite (timeout) para espera de pacotes ou ACKs (em segundos)
TIMEOUT = 3

# Tamanho da janela de envio (quantos pacotes podem ser enviados sem esperar ACK)
WINDOW_SIZE = 5

# Tamanho de cada fragmento de dados enviado (em bytes)
CHUNK_SIZE = 1024

# Cria um pacote com cabeçalho e dados
def criar_pacote(tipo, seq, dados=b""):
    # Cabeçalho: tipo (1 byte), número de sequência (4 bytes) + dados
    return struct.pack("!BI", tipo, seq) + dados

# Lê um pacote e separa o tipo, número de sequência e os dados
def interpretar_pacote(pacote):
    # Garante que o pacote tenha pelo menos 5 bytes (cabeçalho)
    if len(pacote) < 5:
        return None, None, None
    # Desempacota o tipo (1 byte) e sequência (4 bytes)
    tipo, seq = struct.unpack("!BI", pacote[:5])
    # Retorna: tipo, número de sequência e os dados (a partir do byte 5)
    return tipo, seq, pacote[5:]

# Envia dados em "janelas" com confiabilidade (ACKs + retransmissão)
def enviar_janela(sock, dados, addr):
    # Se não houver dados, envia um pacote de fim de transmissão (tipo 3)
    if not dados:
        sock.sendto(criar_pacote(3, 0), addr)
        return

    # Divide os dados em pacotes (fragmentos de CHUNK_SIZE)
    pacotes = []
    for i, offset in enumerate(range(0, len(dados), CHUNK_SIZE)):
        chunk = dados[offset:offset + CHUNK_SIZE]
        pacotes.append(criar_pacote(1, i, chunk))  # tipo 1 = pacote de dados

    base = 0  # início da janela
    sock.settimeout(TIMEOUT)  # define o tempo limite de espera por ACK

    # Enquanto ainda houver pacotes não confirmados
    while base < len(pacotes):
        # Envia todos os pacotes dentro da janela (até WINDOW_SIZE)
        for i in range(base, min(base + WINDOW_SIZE, len(pacotes))):
            sock.sendto(pacotes[i], addr)

        try:
            # Espera um ACK
            ack_data, _ = sock.recvfrom(1024)
            tipo, ack_seq, _ = interpretar_pacote(ack_data)

            # Se for ACK (tipo 2) e válido, avança a base da janela
            if tipo == 2 and ack_seq >= base:
                base = ack_seq + 1

        except socket.timeout:
            # Se não recebeu ACK no tempo esperado, reenvia a janela
            pass

    # Envia 3 vezes o pacote de fim de transmissão (tipo 3) para garantir entrega
    for _ in range(3):
        sock.sendto(criar_pacote(3, 0), addr)

# Recebe dados enviados com janela deslizante e ACKs
def receber_janela(sock, addr):
    dados_recebidos = {}  # Dicionário para armazenar pacotes por sequência
    sock.settimeout(TIMEOUT * 2)  # Tempo para aguardar pacotes

    while True:
        try:
            # Recebe um pacote
            pacote_data, endereco = sock.recvfrom(2048)

            # Ignora pacotes de outros endereços
            if endereco != addr:
                continue

            # Interpreta o pacote
            tipo, seq, dados = interpretar_pacote(pacote_data)

            # Se for pacote de fim de transmissão (tipo 3), responde com ACK e encerra
            if tipo == 3:
                sock.sendto(criar_pacote(2, seq), endereco)  # Envia ACK final
                break

            # Se for um pacote de dados (tipo 1)
            elif tipo == 1:
                dados_recebidos[seq] = dados  # Armazena fragmento
                sock.sendto(criar_pacote(2, seq), endereco)  # Envia ACK

        except socket.timeout:
            # Sai do loop se o tempo expirar
            break

    # Junta os dados recebidos em ordem de sequência e retorna
    if dados_recebidos:
        return b"".join(dados_recebidos[i] for i in sorted(dados_recebidos))
    return None
